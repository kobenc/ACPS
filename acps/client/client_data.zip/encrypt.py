import platform
import sys
import time
from shutil import copyfile
from tempfile import TemporaryDirectory

import numpy
from sklearn.datasets import load_breast_cancer

from concrete.ml.deployment import FHEModelClient, FHEModelDev, FHEModelServer
from concrete.ml.sklearn import XGBClassifier

def save_encrypted_data(encrypted_data):
        with open(client_dir + "/encrypted_data", "wb") as f:
            f.write(encrypted_data)

client_dir="."


fhemodel_client = FHEModelClient(client_dir, key_dir=client_dir)

X, y = load_breast_cancer(return_X_y=True)

clear_input = X[[0], :]
encrypted_input = fhemodel_client.quantize_encrypt_serialize(clear_input)


save_encrypted_data(encrypted_input)


