import inspect
import platform
import sys
import time
from shutil import copyfile
from tempfile import TemporaryDirectory


from concrete.ml.deployment import FHEModelClient, FHEModelDev, FHEModelServer
from concrete.ml.sklearn import XGBClassifier

client_dir="."

def save_evaluation_key(serialized_evaluation_keys):
        with open(client_dir + "/serialized_evaluation_keys.ekl", "wb") as f:
            f.write(serialized_evaluation_keys)


fhemodel_client = FHEModelClient(client_dir, key_dir=client_dir)
fhemodel_client.generate_private_and_evaluation_keys()
serialized_evaluation_keys = fhemodel_client.get_serialized_evaluation_keys()
save_evaluation_key(serialized_evaluation_keys)



