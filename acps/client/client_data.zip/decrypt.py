import sys

from concrete.ml.deployment import FHEModelClient, FHEModelDev, FHEModelServer




client_dir=""

filename=sys.argv[1]

with open(filename, "rb") as f:
    encrypted_prediction = f.read()



fhemodel_client = FHEModelClient(client_dir, key_dir=client_dir)

decrypted_prediction = fhemodel_client.deserialize_decrypt_dequantize(encrypted_prediction)[0]

print(decrypted_prediction)


